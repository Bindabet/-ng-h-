# Samsung Đồng Hồ Kính Lỏng Widget

Dự án Android Studio bằng **Java** tạo widget đồng hồ số cho điện thoại Samsung, với giao diện **glassmorphism / kính lỏng lấy cảm hứng từ iPhone**.

## Bản nâng cấp mới

So với bản trước, phiên bản này đã được làm lại theo yêu cầu:

- **Giống iPhone hơn**:
  - chữ giờ lớn hơn,
  - bố cục sạch hơn,
  - nền kính sáng hơn,
  - bo góc lớn hơn,
  - chip thông tin tinh gọn hơn.
- **Có thêm thời tiết**.
- **Có thêm pin điện thoại**.
- **Có thêm ngày tháng**.

## Tính năng

- Widget màn hình chính hiển thị:
  - **giờ và phút** theo thời gian thực,
  - **ngày tháng**,
  - **thời tiết hiện tại**,
  - **mức pin điện thoại**.
- 3 tông màu kính:
  - Pha lê
  - Xanh băng
  - Hồng sương
- Tùy chọn:
  - hiện/ẩn ngày tháng,
  - tự động lấy vị trí,
  - nhập thủ công thành phố dự phòng.
- Nhấn vào widget để mở ứng dụng cài đặt.
- Có nút yêu cầu thêm widget lên màn hình chính.
- Không cần Google Play Services.
- Dùng `TextClock` để hệ thống tự cập nhật thời gian.
- Dùng **Open-Meteo** để lấy thời tiết, không cần API key.

## Quyền sử dụng

Ứng dụng có thể yêu cầu:

- `INTERNET`: để tải thời tiết.
- `ACCESS_COARSE_LOCATION` / `ACCESS_FINE_LOCATION`: để lấy thời tiết theo vị trí hiện tại.

Nếu không cấp quyền vị trí, ứng dụng sẽ dùng **thành phố bạn nhập thủ công** hoặc mặc định là **Hà Nội**.

## Giới hạn kỹ thuật

Android widget dùng `RemoteViews`, vì vậy **không thể có blur động thật 100% như widget iPhone gốc**. Dự án này mô phỏng phong cách đó bằng:

- nền bán trong suốt,
- bo góc lớn,
- viền sáng,
- lớp phản quang phía trên,
- chip thông tin bán trong suốt.

## Mở dự án

1. Mở Android Studio.
2. Chọn **Open** và mở thư mục dự án này.
3. Đợi Gradle sync hoàn tất.

## Tạo APK

Trong Android Studio:

**Build → Build APK(s)**

APK debug sẽ nằm tại:

`app/build/outputs/apk/debug/app-debug.apk`

## Cài widget trên Samsung

1. Cài APK lên điện thoại.
2. Mở ứng dụng **Đồng hồ kính lỏng**.
3. Chọn màu, chế độ thời tiết và lưu.
4. Nhấn giữ màn hình chính Samsung.
5. Chọn **Widget**.
6. Tìm **Đồng hồ kính lỏng**.
7. Kéo widget ra màn hình chính.

## Cấu trúc chính

- `MainActivity.java`: màn hình tùy chỉnh + xem trước.
- `NoteWidgetProvider.java`: cập nhật widget.
- `WidgetStorage.java`: lưu cài đặt.
- `WeatherRepository.java`: lấy dữ liệu thời tiết.
- `BatteryHelper.java`: lấy mức pin hiện tại.
- `res/layout/widget_clock.xml`: giao diện widget.
- `res/drawable/widget_bg_*.xml`: nền kính lỏng.

## Gợi ý nâng cấp thêm

Bạn có thể mở rộng tiếp:

- đồng hồ có **giây**,
- đồng hồ **theo kiểu Dynamic Island / Lock Screen**,
- **nhiều bố cục widget** 4x2, 4x4, 2x2,
- thời tiết có **icon riêng đẹp hơn**,
- thêm **dự báo 3 ngày**,
- thêm **mức pin bằng thanh tiến trình**.

## Tạo APK bằng GitHub Actions (không cần cài Android Studio)

1. Đăng nhập GitHub, tạo một repository **Private** hoặc Public.
2. Giải nén file ZIP mã nguồn, tải **nội dung bên trong** (gồm `app`, `.github`, `gradle`, `build.gradle`, v.v.) vào **thư mục gốc repository**. Đừng tải nguyên file ZIP và đừng đặt tất cả trong thư mục con.
3. Vào **Actions** → **Build Android APK** → **Run workflow** (hoặc đợi workflow tự chạy sau khi push).
4. Sau khi workflow thành công, mở lần chạy đó, vào **Artifacts** và tải `SamsungDongHoWidget-debug-APK`.
5. Giải nén artifact để lấy `app-debug.apk` và chép sang Samsung để cài.

> Mã nguồn đã qua kiểm tra XML và cấu trúc. Bản ZIP này **chưa được biên dịch thành APK hay thử cài trên điện thoại**; quá trình build và kiểm thử cần Android SDK/Gradle trên máy hoặc GitHub Actions.

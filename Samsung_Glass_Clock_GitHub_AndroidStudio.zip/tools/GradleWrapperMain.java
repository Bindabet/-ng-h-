package org.gradle.wrapper;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Tiny, auditable Gradle downloader for this sample project. NOT the official Gradle wrapper.
 * To use the official wrapper instead, run `gradle wrapper --gradle-version 8.11.1`.
 * Java 17+ required. Downloads from services.gradle.org and runs Gradle locally.
 */
public final class GradleWrapperMain {
    private GradleWrapperMain() {}

    public static void main(String[] args) throws Exception {
        Path project = Path.of(System.getProperty("user.dir"));
        Path propsPath = project.resolve("gradle/wrapper/gradle-wrapper.properties");
        if (!Files.isRegularFile(propsPath)) {
            System.err.println("Run this command from the root of the Android project.");
            System.exit(2);
        }
        Properties props = new Properties();
        try (InputStream input = Files.newInputStream(propsPath)) {
            props.load(input);
        }
        String distribution = props.getProperty("distributionUrl", "");
        if (!distribution.matches("https://services\\.gradle\\.org/distributions/gradle-[0-9.]+-bin\\.zip")) {
            throw new IOException("Unexpected Gradle distribution URL: " + distribution);
        }
        String version = distribution.substring(distribution.lastIndexOf("/gradle-") + 8,
                distribution.lastIndexOf("-bin.zip"));
        Path storage = Path.of(System.getProperty("user.home"), ".gradle", "wrapper", "dists", "samsung-note-widget");
        Path install = storage.resolve("gradle-" + version);
        boolean windows = System.getProperty("os.name").toLowerCase().contains("win");
        Path executable = install.resolve(windows ? "bin/gradle.bat" : "bin/gradle");
        if (!Files.exists(executable)) {
            Files.createDirectories(storage);
            System.out.println("Downloading Gradle " + version + " from the official distribution URL...");
            Path archive = Files.createTempFile(storage, "gradle-", ".zip");
            try {
                HttpClient client = HttpClient.newBuilder()
                        .followRedirects(HttpClient.Redirect.NORMAL)
                        .connectTimeout(Duration.ofSeconds(30)).build();
                HttpRequest request = HttpRequest.newBuilder(URI.create(distribution))
                        .timeout(Duration.ofMinutes(10)).GET().build();
                HttpResponse<Path> response = client.send(request, HttpResponse.BodyHandlers.ofFile(archive));
                if (response.statusCode() != 200) {
                    throw new IOException("Gradle download failed: HTTP " + response.statusCode());
                }
                extractSafely(archive, storage);
                if (!Files.exists(executable)) {
                    throw new IOException("Gradle distribution missing expected bin/gradle");
                }
                if (!windows) executable.toFile().setExecutable(true, false);
            } finally {
                Files.deleteIfExists(archive);
            }
        }
        List<String> command = new ArrayList<>();
        if (windows) {
            command.add("cmd.exe");
            command.add("/c");
        }
        command.add(executable.toAbsolutePath().toString());
        for (String arg : args) command.add(arg);
        Process child = new ProcessBuilder(command).directory(project.toFile()).inheritIO().start();
        System.exit(child.waitFor());
    }

    private static void extractSafely(Path zip, Path destination) throws IOException {
        try (ZipInputStream input = new ZipInputStream(
                new BufferedInputStream(Files.newInputStream(zip)))) {
            ZipEntry entry;
            while ((entry = input.getNextEntry()) != null) {
                Path target = destination.resolve(entry.getName()).normalize();
                if (!target.startsWith(destination)) {
                    throw new IOException("Unsafe zip entry: " + entry.getName());
                }
                if (entry.isDirectory()) {
                    Files.createDirectories(target);
                } else {
                    Files.createDirectories(target.getParent());
                    Files.copy(input, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                }
                input.closeEntry();
            }
        }
    }
}

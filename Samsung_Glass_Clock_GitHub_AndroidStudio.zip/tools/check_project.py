#!/usr/bin/env python3
"""Offline XML + structural validation, not an APK compilation test."""
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent.parent
app = root / 'app/src/main'
res = app / 'res'
for p in [app / 'AndroidManifest.xml', *res.rglob('*.xml')]:
    ET.parse(p)
    print('XML OK:', p.relative_to(root))

assert (res / 'layout/widget_clock.xml').exists()
assert (res / 'xml/clock_widget_info.xml').exists()
assert (res / 'drawable/widget_preview.png').exists()
for file in ['widget_bg_clear.xml','widget_bg_blue.xml','widget_bg_pink.xml','widget_glass_top_highlight.xml','widget_info_chip.xml']:
    assert (res / 'drawable' / file).exists(), file
for kind in ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']:
    assert (res / f'mipmap-{kind}/ic_launcher.png').exists()
for file in (app / 'java').rglob('*.java'):
    source = file.read_text(encoding='utf-8')
    assert 'package com.widgetnhanh.samsung;' in source
    assert source.count('{') == source.count('}')
    print('JAVA SOURCE OK:', file.name)
widget = (res / 'layout/widget_clock.xml').read_text(encoding='utf-8')
for token in ['widget_weather', 'widget_battery', 'widget_date', 'widget_time']:
    assert token in widget, token
assert 'updatePeriodMillis="1800000"' in (res / 'xml/clock_widget_info.xml').read_text(encoding='utf-8')
manifest = (app / 'AndroidManifest.xml').read_text(encoding='utf-8')
for token in ['NoteWidgetProvider', 'clock_widget_info', 'android.permission.INTERNET']:
    assert token in manifest, token
print('OK: offline structural checks passed; build with Android Studio or GitHub Actions.')

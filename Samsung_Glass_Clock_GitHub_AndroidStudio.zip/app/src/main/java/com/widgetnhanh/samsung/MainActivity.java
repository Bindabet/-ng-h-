package com.widgetnhanh.samsung;

import android.Manifest;
import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

/** Settings screen + live preview for the liquid-glass widget. */
public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 77;
    private static final int PAGE_BG = 0xFF0B1020;
    private static final int WHITE = Color.WHITE;
    private static final int MUTED = 0xFFAEB8D6;
    private static final int[] PALETTE = {0x4DFFFFFF, 0x5C90C8FF, 0x5CE8B0D0};
    private static final int[] STROKES = {0xAAFFFFFF, 0xB5F6FBFF, 0xB5FFF5FB};
    private static final String[] THEME_NAMES = {"Pha lê", "Xanh băng", "Hồng sương"};

    private int selectedTheme;
    private boolean showDate;
    private boolean autoLocation;
    private LinearLayout previewCard;
    private TextClock previewDate;
    private TextView previewWeather;
    private TextView previewBattery;
    private TextView[] themeButtons;
    private Switch showDateSwitch;
    private Switch autoLocationSwitch;
    private EditText cityInput;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(PAGE_BG);
        getWindow().setNavigationBarColor(PAGE_BG);
        selectedTheme = WidgetStorage.theme(this);
        showDate = WidgetStorage.showDate(this);
        autoLocation = WidgetStorage.autoLocation(this);
        buildInterface();
        refreshPreview();
        if (WidgetStorage.isWeatherStale(this)) {
            refreshWeather(false);
        }
    }

    private void buildInterface() {
        ScrollView scrolling = new ScrollView(this);
        scrolling.setFillViewport(true);
        scrolling.setFitsSystemWindows(true);
        scrolling.setBackgroundColor(PAGE_BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(26), dp(22), dp(32));
        scrolling.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scrolling);

        TextView eyebrow = text("WIDGET MÀN HÌNH CHÍNH", 11, 0xFFAFC2FF, true);
        eyebrow.setLetterSpacing(0.14f);
        root.addView(eyebrow);

        root.addView(text("Đồng hồ kính lỏng", 30, WHITE, true), topMargin(10));
        TextView description = text(
                "Bản nâng cấp giống iPhone hơn: chữ giờ lớn hơn, bố cục sạch hơn, kính sáng hơn, kèm thời tiết, pin và ngày tháng.",
                14, MUTED, false);
        description.setLineSpacing(dp(3), 1f);
        root.addView(description, topMargin(9));

        TextView previewLabel = text("XEM TRƯỚC WIDGET", 11, 0xFFAFC2FF, true);
        previewLabel.setLetterSpacing(0.12f);
        root.addView(previewLabel, topMargin(28));

        previewCard = new LinearLayout(this);
        previewCard.setOrientation(LinearLayout.VERTICAL);
        previewCard.setGravity(Gravity.CENTER_VERTICAL);
        previewCard.setPadding(dp(22), dp(18), dp(22), dp(18));
        previewCard.setMinimumHeight(dp(170));
        root.addView(previewCard, topMargin(12));

        previewDate = new TextClock(this);
        previewDate.setFormat24Hour("EEE, dd/MM/yyyy");
        previewDate.setFormat12Hour("EEE, dd/MM/yyyy");
        previewDate.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        previewDate.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        previewDate.setTextColor(0xF2FFFFFF);
        previewCard.addView(previewDate);

        TextClock previewTime = new TextClock(this);
        previewTime.setFormat24Hour("HH:mm");
        previewTime.setFormat12Hour("h:mm");
        previewTime.setTextSize(TypedValue.COMPLEX_UNIT_SP, 64);
        previewTime.setSingleLine(true);
        previewTime.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        previewTime.setTextColor(WHITE);
        previewTime.setIncludeFontPadding(false);
        previewCard.addView(previewTime, topMargin(3));

        LinearLayout infoRow = new LinearLayout(this);
        infoRow.setOrientation(LinearLayout.HORIZONTAL);
        previewCard.addView(infoRow, topMargin(8));

        previewWeather = text(WidgetStorage.weatherText(this), 12, WHITE, true);
        previewWeather.setPadding(dp(12), dp(8), dp(12), dp(8));
        infoRow.addView(previewWeather, weighted());

        previewBattery = text(BatteryHelper.currentBatteryText(this), 12, WHITE, true);
        previewBattery.setPadding(dp(12), dp(8), dp(12), dp(8));
        LinearLayout.LayoutParams batteryParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        batteryParams.leftMargin = dp(8);
        infoRow.addView(previewBattery, batteryParams);

        TextView paletteLabel = text("TÔNG MÀU KÍNH", 11, 0xFFD4DEFF, true);
        paletteLabel.setLetterSpacing(0.12f);
        root.addView(paletteLabel, topMargin(28));

        LinearLayout colors = new LinearLayout(this);
        colors.setOrientation(LinearLayout.HORIZONTAL);
        themeButtons = new TextView[3];
        for (int i = 0; i < 3; i++) {
            final int next = i;
            TextView option = text(THEME_NAMES[i], 11, WHITE, true);
            option.setGravity(Gravity.CENTER);
            option.setPadding(dp(2), dp(15), dp(2), dp(15));
            option.setOnClickListener(view -> {
                selectedTheme = next;
                refreshPreview();
            });
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1);
            if (i > 0) params.leftMargin = dp(8);
            colors.addView(option, params);
            themeButtons[i] = option;
        }
        root.addView(colors, topMargin(11));

        showDateSwitch = new Switch(this);
        showDateSwitch.setText("Hiển thị ngày tháng");
        showDateSwitch.setTextColor(WHITE);
        showDateSwitch.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        showDateSwitch.setPadding(0, dp(10), 0, dp(10));
        showDateSwitch.setChecked(showDate);
        showDateSwitch.setOnCheckedChangeListener((button, checked) -> {
            showDate = checked;
            refreshPreview();
        });
        root.addView(showDateSwitch, topMargin(18));

        autoLocationSwitch = new Switch(this);
        autoLocationSwitch.setText("Tự động lấy vị trí cho thời tiết");
        autoLocationSwitch.setTextColor(WHITE);
        autoLocationSwitch.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        autoLocationSwitch.setPadding(0, dp(10), 0, dp(10));
        autoLocationSwitch.setChecked(autoLocation);
        autoLocationSwitch.setOnCheckedChangeListener((button, checked) -> {
            autoLocation = checked;
            cityInput.setEnabled(!checked);
            cityInput.setAlpha(checked ? 0.5f : 1f);
            if (checked && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            }
        });
        root.addView(autoLocationSwitch, topMargin(6));

        TextView cityLabel = text("Thành phố dự phòng / thủ công", 12, 0xFFD6DEF7, true);
        root.addView(cityLabel, topMargin(10));

        cityInput = new EditText(this);
        cityInput.setText(WidgetStorage.city(this));
        cityInput.setTextColor(WHITE);
        cityInput.setHintTextColor(0x80FFFFFF);
        cityInput.setHint("Ví dụ: Hà Nội, Đà Nẵng, TP.HCM");
        cityInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        cityInput.setPadding(dp(16), dp(14), dp(16), dp(14));
        cityInput.setBackground(rounded(0x22FFFFFF, 16, 0x55FFFFFF, 1));
        cityInput.setEnabled(!autoLocation);
        cityInput.setAlpha(autoLocation ? 0.5f : 1f);
        root.addView(cityInput, topMargin(8));

        TextView refresh = actionButton("Cập nhật thời tiết ngay", 0x33FFFFFF, WHITE);
        refresh.setOnClickListener(view -> {
            persistSettings();
            refreshWeather(true);
        });
        root.addView(refresh, topMargin(18));

        TextView save = actionButton("Lưu giao diện đồng hồ", 0xFF7D8FFF, WHITE);
        save.setOnClickListener(view -> saveChanges(true));
        root.addView(save, topMargin(12));

        TextView add = actionButton("＋  Thêm widget lên màn hình chính", 0xFF252C44, WHITE);
        add.setOnClickListener(view -> {
            saveChanges(false);
            requestWidgetPin();
        });
        root.addView(add, topMargin(12));

        TextView hint = text(
                "Nếu không hiện hộp thoại: nhấn giữ vùng trống trên màn hình chính Samsung → Widget → Đồng hồ kính lỏng → Thêm.",
                12, MUTED, false);
        hint.setLineSpacing(dp(3), 1f);
        root.addView(hint, topMargin(16));
    }

    private void refreshPreview() {
        if (previewCard == null || themeButtons == null || previewDate == null) return;
        previewCard.setBackground(glassCard(PALETTE[selectedTheme], STROKES[selectedTheme], 28));
        previewDate.setVisibility(showDate ? View.VISIBLE : View.GONE);
        previewWeather.setBackground(chipBackground());
        previewBattery.setBackground(chipBackground());
        previewWeather.setText(WidgetStorage.weatherText(this));
        previewBattery.setText(BatteryHelper.currentBatteryText(this));
        for (int i = 0; i < themeButtons.length; i++) {
            boolean active = i == selectedTheme;
            themeButtons[i].setBackground(optionChip(PALETTE[i], STROKES[i], active));
        }
    }

    private void persistSettings() {
        WidgetStorage.save(this, selectedTheme, showDate, autoLocation, cityInput.getText().toString());
        NoteWidgetProvider.updateAll(this);
    }

    private void saveChanges(boolean toast) {
        persistSettings();
        WeatherRepository.refreshAsync(this, () -> runOnUiThread(this::refreshPreview));
        if (toast) {
            Toast.makeText(this, "Đã lưu. Đang cập nhật dữ liệu!", Toast.LENGTH_SHORT).show();
        }
        refreshPreview();
    }

    private void refreshWeather(boolean toast) {
        if (autoLocation && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        if (toast) Toast.makeText(this, "Đang cập nhật thời tiết...", Toast.LENGTH_SHORT).show();
        WeatherRepository.refreshAsync(this, () -> runOnUiThread(this::refreshPreview));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            boolean allowed = false;
            for (int result : grantResults) {
                allowed |= (result == PackageManager.PERMISSION_GRANTED);
            }
            if (!allowed) {
                autoLocation = false;
                autoLocationSwitch.setChecked(false);
                Toast.makeText(this,
                        "Chưa cấp quyền vị trí. Đang dùng thành phố thủ công.",
                        Toast.LENGTH_LONG).show();
            }
            saveChanges(false);
        }
    }

    private void requestWidgetPin() {
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && manager.isRequestPinAppWidgetSupported()) {
            boolean requested = manager.requestPinAppWidget(
                    new ComponentName(this, NoteWidgetProvider.class), null, null);
            Toast.makeText(this, requested
                    ? "Hãy xác nhận thêm widget trên Samsung."
                    : "Hãy thêm widget từ màn hình chính.", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this,
                    "Nhấn giữ màn hình chính → Widget → Đồng hồ kính lỏng.", Toast.LENGTH_LONG).show();
        }
    }

    private TextView actionButton(String label, int backgroundColor, int textColor) {
        TextView button = text(label, 15, textColor, true);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(12), dp(17), dp(12), dp(17));
        button.setBackground(rounded(backgroundColor, 15, 0, 0));
        button.setClickable(true);
        button.setFocusable(true);
        return button;
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        view.setTextColor(color);
        view.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        return view;
    }

    private GradientDrawable rounded(int fill, int radiusDp, int stroke, int strokeDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), stroke);
        return drawable;
    }

    private GradientDrawable glassCard(int fill, int stroke, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{lighten(fill, 18), fill, darken(fill, 12)});
        drawable.setCornerRadius(dp(radiusDp));
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private GradientDrawable chipBackground() {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x36FFFFFF, 0x1EFFFFFF});
        drawable.setCornerRadius(dp(18));
        drawable.setStroke(dp(1), 0x55FFFFFF);
        return drawable;
    }

    private GradientDrawable optionChip(int fill, int stroke, boolean active) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{lighten(fill, 16), fill});
        drawable.setCornerRadius(dp(13));
        drawable.setStroke(dp(active ? 2 : 1), active ? 0xEFFFFFFF : stroke);
        return drawable;
    }

    private int lighten(int color, int amount) {
        return Color.argb(Color.alpha(color),
                Math.min(255, Color.red(color) + amount),
                Math.min(255, Color.green(color) + amount),
                Math.min(255, Color.blue(color) + amount));
    }

    private int darken(int color, int amount) {
        return Color.argb(Color.alpha(color),
                Math.max(0, Color.red(color) - amount),
                Math.max(0, Color.green(color) - amount),
                Math.max(0, Color.blue(color) - amount));
    }

    private LinearLayout.LayoutParams topMargin(int marginDp) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = dp(marginDp);
        return params;
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
    }

    private int dp(int value) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                value, getResources().getDisplayMetrics()));
    }
}

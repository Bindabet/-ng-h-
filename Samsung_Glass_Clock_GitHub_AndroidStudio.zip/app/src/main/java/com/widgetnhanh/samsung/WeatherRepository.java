package com.widgetnhanh.samsung;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;


import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;

public final class WeatherRepository {
    private WeatherRepository() { }

    public static void refreshAsync(Context context, Runnable onDone) {
        Context app = context.getApplicationContext();
        new Thread(() -> {
            try {
                String weather = buildWeatherText(app);
                WidgetStorage.saveWeather(app, weather);
            } catch (Exception ignore) {
                if (WidgetStorage.weatherUpdated(app) == 0L) {
                    WidgetStorage.saveWeather(app, "—  Không tải được thời tiết");
                }
            }
            NoteWidgetProvider.updateAll(app);
            if (onDone != null) onDone.run();
        }).start();
    }

    private static String buildWeatherText(Context context) throws Exception {
        double[] latLon;
        String label;
        if (WidgetStorage.autoLocation(context)) {
            Location location = getBestLocation(context);
            if (location != null) {
                latLon = new double[]{location.getLatitude(), location.getLongitude()};
                label = reverseGeocode(context, location);
            } else {
                String city = safeCity(WidgetStorage.city(context));
                Geo geo = geocodeCity(city);
                latLon = new double[]{geo.latitude, geo.longitude};
                label = geo.name;
            }
        } else {
            String city = safeCity(WidgetStorage.city(context));
            Geo geo = geocodeCity(city);
            latLon = new double[]{geo.latitude, geo.longitude};
            label = geo.name;
        }
        Forecast forecast = getForecast(latLon[0], latLon[1]);
        return forecast.icon + " " + forecast.temperature + "°C · " + label;
    }

    private static String safeCity(String city) {
        return city == null || city.trim().isEmpty() ? "Hà Nội" : city.trim();
    }

    private static Location getBestLocation(Context context) {
        boolean coarse = context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
        if (!coarse) return null;
        try {
            LocationManager manager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
            if (manager == null) return null;
            Location best = null;
            for (String provider : manager.getProviders(true)) {
                try {
                    Location last = manager.getLastKnownLocation(provider);
                    if (last != null && (best == null || last.getAccuracy() < best.getAccuracy())) {
                        best = last;
                    }
                } catch (SecurityException ignored) {
                }
            }
            return best;
        } catch (Exception ignored) {
            return null;
        }
    }

    private static String reverseGeocode(Context context, Location location) {
        try {
            Geocoder geocoder = new Geocoder(context, new Locale("vi", "VN"));
            List<Address> list = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            if (list != null && !list.isEmpty()) {
                Address a = list.get(0);
                if (a.getLocality() != null && !a.getLocality().isEmpty()) return a.getLocality();
                if (a.getSubAdminArea() != null && !a.getSubAdminArea().isEmpty()) return a.getSubAdminArea();
            }
        } catch (Exception ignored) {
        }
        return "Vị trí hiện tại";
    }

    private static Geo geocodeCity(String city) throws Exception {
        String q = URLEncoder.encode(city, StandardCharsets.UTF_8.name());
        String endpoint = "https://geocoding-api.open-meteo.com/v1/search?count=1&language=vi&name=" + q;
        JSONObject json = new JSONObject(readUrl(endpoint));
        JSONArray results = json.optJSONArray("results");
        if (results == null || results.length() == 0) {
            throw new IllegalArgumentException("Không tìm thấy thành phố: " + city);
        }
        JSONObject item = results.getJSONObject(0);
        String name = item.optString("name", city);
        return new Geo(item.getDouble("latitude"), item.getDouble("longitude"), name);
    }

    private static Forecast getForecast(double latitude, double longitude) throws Exception {
        String endpoint = "https://api.open-meteo.com/v1/forecast?latitude=" + latitude
                + "&longitude=" + longitude
                + "&current=temperature_2m,weather_code&timezone=auto";
        JSONObject json = new JSONObject(readUrl(endpoint));
        JSONObject current = json.getJSONObject("current");
        int temp = Math.round((float) current.getDouble("temperature_2m"));
        int code = current.optInt("weather_code", 0);
        return new Forecast(temp, weatherIcon(code));
    }

    private static String readUrl(String endpoint) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(endpoint).openConnection();
        connection.setConnectTimeout(10000);
        connection.setReadTimeout(10000);
        connection.setRequestProperty("User-Agent", "SamsungGlassClock/1.0");
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
            StringBuilder builder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) builder.append(line);
            return builder.toString();
        } finally {
            connection.disconnect();
        }
    }

    private static String weatherIcon(int code) {
        switch (code) {
            case 0: return "☀";
            case 1:
            case 2: return "🌤";
            case 3: return "☁";
            case 45:
            case 48: return "🌫";
            case 51:
            case 53:
            case 55:
            case 61:
            case 63:
            case 65:
            case 80:
            case 81:
            case 82: return "🌧";
            case 71:
            case 73:
            case 75:
            case 85:
            case 86: return "❄";
            case 95:
            case 96:
            case 99: return "⛈";
            default: return "🌡";
        }
    }

    private static final class Geo {
        final double latitude;
        final double longitude;
        final String name;

        Geo(double latitude, double longitude, String name) {
            this.latitude = latitude;
            this.longitude = longitude;
            this.name = name;
        }
    }

    private static final class Forecast {
        final int temperature;
        final String icon;

        Forecast(int temperature, String icon) {
            this.temperature = temperature;
            this.icon = icon;
        }
    }
}

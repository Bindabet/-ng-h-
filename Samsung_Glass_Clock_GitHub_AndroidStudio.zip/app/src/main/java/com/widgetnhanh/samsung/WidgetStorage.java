package com.widgetnhanh.samsung;

import android.content.Context;
import android.content.SharedPreferences;

/** Global preferences shared by all widgets on the device. */
public final class WidgetStorage {
    public static final int CLEAR = 0;
    public static final int BLUE = 1;
    public static final int PINK = 2;

    private static final String PREFS = "quick_note_prefs";
    private static final String KEY_THEME = "theme";
    private static final String KEY_SHOW_DATE = "clock_show_date";
    private static final String KEY_AUTO_LOCATION = "auto_location";
    private static final String KEY_CITY = "manual_city";
    private static final String KEY_WEATHER_TEXT = "weather_text";
    private static final String KEY_WEATHER_UPDATED = "weather_updated";

    private WidgetStorage() { }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static int theme(Context context) {
        int stored = prefs(context).getInt(KEY_THEME, CLEAR);
        return Math.max(CLEAR, Math.min(PINK, stored));
    }

    public static boolean showDate(Context context) {
        return prefs(context).getBoolean(KEY_SHOW_DATE, true);
    }

    public static boolean autoLocation(Context context) {
        return prefs(context).getBoolean(KEY_AUTO_LOCATION, false);
    }

    public static String city(Context context) {
        return prefs(context).getString(KEY_CITY, "Hà Nội");
    }

    public static void save(Context context, int theme, boolean showDate,
                            boolean autoLocation, String city) {
        prefs(context).edit()
                .putInt(KEY_THEME, Math.max(CLEAR, Math.min(PINK, theme)))
                .putBoolean(KEY_SHOW_DATE, showDate)
                .putBoolean(KEY_AUTO_LOCATION, autoLocation)
                .putString(KEY_CITY, city == null ? "Hà Nội" : city.trim())
                .apply();
    }

    public static String weatherText(Context context) {
        return prefs(context).getString(KEY_WEATHER_TEXT, "—  Thời tiết chưa cập nhật");
    }

    public static void saveWeather(Context context, String weatherText) {
        prefs(context).edit()
                .putString(KEY_WEATHER_TEXT, weatherText)
                .putLong(KEY_WEATHER_UPDATED, System.currentTimeMillis())
                .apply();
    }

    public static long weatherUpdated(Context context) {
        return prefs(context).getLong(KEY_WEATHER_UPDATED, 0L);
    }

    public static boolean isWeatherStale(Context context) {
        long last = weatherUpdated(context);
        return last == 0L || (System.currentTimeMillis() - last) > 30L * 60L * 1000L;
    }
}

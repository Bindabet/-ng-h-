package com.widgetnhanh.samsung;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RemoteViews;

/**
 * Home-screen clock widget with an iPhone-inspired liquid-glass layout.
 */
public class NoteWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int widgetId : appWidgetIds) {
            updateOne(context, manager, widgetId);
        }
        if (WidgetStorage.isWeatherStale(context)) {
            WeatherRepository.refreshAsync(context, null);
        }
    }

    public static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName provider = new ComponentName(context, NoteWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(provider);
        for (int id : ids) {
            updateOne(context, manager, id);
        }
    }

    private static void updateOne(Context context, AppWidgetManager manager, int id) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_clock);
        int background;
        switch (WidgetStorage.theme(context)) {
            case WidgetStorage.BLUE:
                background = R.drawable.widget_bg_blue;
                break;
            case WidgetStorage.PINK:
                background = R.drawable.widget_bg_pink;
                break;
            default:
                background = R.drawable.widget_bg_clear;
        }
        views.setImageViewResource(R.id.widget_background, background);
        views.setViewVisibility(R.id.widget_date,
                WidgetStorage.showDate(context) ? View.VISIBLE : View.GONE);
        views.setTextViewText(R.id.widget_weather, WidgetStorage.weatherText(context));
        views.setTextViewText(R.id.widget_battery, BatteryHelper.currentBatteryText(context));

        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent click = PendingIntent.getActivity(context, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, click);
        manager.updateAppWidget(id, views);
    }
}
